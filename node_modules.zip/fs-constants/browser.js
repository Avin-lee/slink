module.exports = require('constants')

/* eslint import/no-extraneous-dependencies: off */

import "core-js/features/symbol";
import "core-js/features/symbol/iterator";
import "core-js/features/object";
import "core-js/features/number/is-nan";
import "core-js/features/array";
import "core-js/features/string/virtual/starts-with";
import "core-js/features/string/virtual/repeat";
import "core-js/features/math/trunc";
import "core-js/features/math/sign";

export * from "./luxon.js";

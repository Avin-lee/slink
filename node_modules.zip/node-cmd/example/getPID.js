var cmd=require('../cmd.js');

var processRef=cmd.get('node');
console.log(processRef.pid);
